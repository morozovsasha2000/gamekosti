const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));  // раздаём файлы из папки public

// -------------------------------
// ХРАНЕНИЕ СОСТОЯНИЯ НА СЕРВЕРЕ
// -------------------------------
const games = {};        // игры по roomId
const playersInLobby = []; // игроки, ожидающие начала

// -------------------------------
// Socket.IO: подключение
// -------------------------------
io.on('connection', (socket) => {
    console.log(`Игрок подключился: ${socket.id}`);

    // --- ЛОББИ ---

    // Игрок вводит ник и заходит в лобби
    socket.on('joinLobby', (nickname) => {
        socket.nickname = nickname;
        socket.isHost = false;
        playersInLobby.push({
            id: socket.id,
            nickname: nickname
        });
        console.log(`Лобби: ${nickname} (${socket.id}). Всего: ${playersInLobby.length}`);
        
        // Отправляем обновлённый список всем в лобби
        io.emit('lobbyUpdate', playersInLobby);
    });

    // Хост нажимает "Начать игру"
    socket.on('startGame', () => {
        if (playersInLobby.length < 2) {
            socket.emit('error', 'Нужно минимум 2 игрока');
            return;
        }

        const roomId = 'game_' + Date.now();
        const gamePlayers = [...playersInLobby]; // копируем текущих игроков
        games[roomId] = {
            players: gamePlayers,
            board: createEmptyBoard(),
            currentPlayerIndex: 0,
            diceValues: null,
            gameOver: false
        };

        // Перемещаем всех в комнату
        gamePlayers.forEach(p => {
            const s = io.sockets.sockets.get(p.id);
            if (s) {
                s.join(roomId);
                s.roomId = roomId;
                s.gamePlayerId = p.id;
            }
        });

        // Очищаем лобби
        playersInLobby.length = 0;

        // Отправляем игрокам данные игры
        io.to(roomId).emit('gameStarted', {
            players: gamePlayers,
            board: games[roomId].board,
            currentPlayerIndex: 0
        });

        io.emit('lobbyUpdate', playersInLobby); // обновляем лобби для оставшихся
        console.log(`Игра началась в комнате ${roomId}, игроков: ${gamePlayers.length}`);
    });

    // --- ИГРА ---

    // Бросок кубиков
    socket.on('rollDice', () => {
        const roomId = socket.roomId;
        const game = games[roomId];
        if (!game || game.gameOver) return;

        const playerIndex = game.players.findIndex(p => p.id === socket.id);
        if (playerIndex !== game.currentPlayerIndex) return;

        // Если уже бросили и не дубль — повторный бросок запрещён
        if (game.diceValues && !game.diceValues.isDouble) return;

        const d1 = Math.floor(Math.random() * 6) + 1;
        const d2 = Math.floor(Math.random() * 6) + 1;
        game.diceValues = { dice1: d1, dice2: d2, isDouble: d1 === d2 };

        const possibleMoves = getPossibleMovesForGame(game, d1, d2);

        io.to(roomId).emit('diceRolled', {
            dice: game.diceValues,
            possibleMoves: possibleMoves,
            currentPlayerIndex: game.currentPlayerIndex
        });
    });

    // Ход игрока (выбор клетки)
    socket.on('makeMove', (cellKey) => {
        const roomId = socket.roomId;
        const game = games[roomId];
        if (!game || game.gameOver) return;

        const playerIndex = game.players.findIndex(p => p.id === socket.id);
        if (playerIndex !== game.currentPlayerIndex) return;
        if (!game.diceValues) return;

        const possibleMoves = getPossibleMovesForGame(game, game.diceValues.dice1, game.diceValues.dice2);
        if (!possibleMoves.includes(cellKey)) return;

        const currentOccupant = game.board[cellKey];

        if (currentOccupant === null) {
            // Пустая клетка — занимаем
            game.board[cellKey] = playerIndex;

            if (checkWinForGame(game, playerIndex)) {
                game.gameOver = true;
                io.to(roomId).emit('gameOver', {
                    winner: game.players[playerIndex],
                    board: game.board
                });
                return;
            }
        } else if (currentOccupant !== playerIndex) {
            // Чужая клетка — сбиваем
            game.board[cellKey] = null;
        } else {
            return; // своя клетка
        }

        // Переход хода
        if (game.diceValues && game.diceValues.isDouble && currentOccupant === null) {
            // дубль и клетка была пустая — бросает ещё раз
            game.diceValues = null;
        } else {
            game.currentPlayerIndex = (game.currentPlayerIndex + 1) % game.players.length;
            game.diceValues = null;
        }

        io.to(roomId).emit('gameStateUpdate', {
            board: game.board,
            currentPlayerIndex: game.currentPlayerIndex,
            diceValues: null
        });
    });

    // Отключение
    socket.on('disconnect', () => {
        // Удаляем из лобби
        const lobbyIndex = playersInLobby.findIndex(p => p.id === socket.id);
        if (lobbyIndex !== -1) {
            playersInLobby.splice(lobbyIndex, 1);
            io.emit('lobbyUpdate', playersInLobby);
        }

        // Если игрок был в игре — уведомляем
        if (socket.roomId && games[socket.roomId]) {
            io.to(socket.roomId).emit('playerDisconnected', {
                nickname: socket.nickname || 'Неизвестный'
            });
        }

        console.log(`Игрок отключился: ${socket.nickname || socket.id}`);
    });
});

// -------------------------------
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// -------------------------------
function createEmptyBoard() {
    const board = {};
    for (let r = 1; r <= 6; r++) {
        for (let c = 1; c <= 6; c++) {
            board[r * 10 + c] = null;
        }
    }
    return board;
}

function getPossibleMovesForGame(game, d1, d2) {
    const move1 = d1 * 10 + d2;
    const move2 = d2 * 10 + d1;
    const moves = [];
    const playerIndex = game.currentPlayerIndex;

    if (game.board[move1] === null || game.board[move1] !== playerIndex) moves.push(move1);
    if (move1 !== move2 && (game.board[move2] === null || game.board[move2] !== playerIndex)) moves.push(move2);
    return moves;
}

function checkWinForGame(game, playerIndex) {
    const grid = [];
    for (let r = 1; r <= 6; r++) {
        const row = [];
        for (let c = 1; c <= 6; c++) {
            row.push(game.board[r * 10 + c]);
        }
        grid.push(row);
    }

    for (let r = 0; r < 6; r++) {
        for (let c = 0; c < 6; c++) {
            if (grid[r][c] !== playerIndex) continue;
            if (c <= 3 && grid[r][c+1] === playerIndex && grid[r][c+2] === playerIndex) return true;
            if (r <= 3 && grid[r+1][c] === playerIndex && grid[r+2][c] === playerIndex) return true;
            if (r <= 3 && c <= 3 && grid[r+1][c+1] === playerIndex && grid[r+2][c+2] === playerIndex) return true;
            if (r <= 3 && c >= 2 && grid[r+1][c-1] === playerIndex && grid[r+2][c-2] === playerIndex) return true;
        }
    }
    return false;
}

// -------------------------------
// ЗАПУСК СЕРВЕРА
// -------------------------------
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Сервер запущен на http://localhost:${PORT}`);
});